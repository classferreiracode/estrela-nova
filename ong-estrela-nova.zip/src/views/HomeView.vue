<script setup>
import SliderComponent from '@/components/SliderComponent.vue'
</script>
<template>
    <SliderComponent />
    <h1>Home</h1>
</template>
